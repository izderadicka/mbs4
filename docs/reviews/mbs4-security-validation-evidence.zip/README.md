# MBS4 security validation evidence — 18 October 2026

Backend: 4c2313fef98640943061067cfe8529522b4bad5c.
Frontend available: 227d9c922989c5c7e4da361a63076b0f06b1dee9; reader.svelte unchanged from reviewed c12911803a8b0bb02ce399c7d2435b977f8cef01.
Foliate: 78914aef4466eb960965702401634c2cb348e9b1.
Rust/Cargo 1.99.1; Chromium 154.0.8037.57.

These tests ASSERT VULNERABLE BEHAVIOR. Passing means reproduction, not remediation.
No tracked application files were edited. All tests use synthetic users/data.

## Commands in this environment

Activate before Rust commands:

    . /workspace/.setup/activate.sh

Baseline from /workspace/mbs4:

    cargo test --workspace --locked --offline -- --skip oidc::tests::test_discovery
    cargo test --locked --offline -p mbs4-auth oidc::tests::test_discovery -- --nocapture

Together: 146 passed, 1 existing ignored test. The second run successfully exercised external discovery.
Local server tests need permission to bind sockets; sandbox-only runs failed with EPERM.
Cargo --offline prevents registry access; it does not stop a test from contacting an external service.

From the included harness directory (manifest uses absolute /workspace/mbs4 paths):

    CARGO_TARGET_DIR=/workspace/mbs4/target cargo test --offline -- --nocapture --test-threads=1

Recorded runs split five HTTP tests and one claim-conversion test; all passed.
Harness Cargo.lock adds only the harness package relative to package versions in backend Cargo.lock.
cargo fmt was attempted but rustfmt is not installed in either available toolchain. No tracked Rust files were changed.

Browser proof, with scripts beside one another and the frontend dependencies installed at /workspace/mbs4-client/node_modules:

    python make_epubs.py
    node browser.mjs

This launches a loopback server on a random port and headless Chromium. Four cases cover two EPUB layouts under default CSP and script-src 'self' control. The marker cookie is synthetic and HttpOnly. No real account/session credentials are used. The server/browser close after the test. This is the real Foliate loader/renderer in a minimal harness, not the full Svelte UI.

## Evidence interpretation

F2 exercises claim conversion from locally signed token objects, not external login/callback/signature bypass.
F3 tests HTTP CORS headers and preflight using bearer auth; browser cookie delivery remains conditional.
F4/F5 use an actual worker-generated ZIP with a failed-conversion manifest, showing disclosure without Calibre processing.
F6 uses a nonexistent account and synthetic documentation IPs, never real passwords.
F7 sends only 1 MiB + 17 bytes. Multipart control is rejected with 500; cleanup was not inspected.
F8 manually forwards a test session cookie over loopback, then validates newly issued admin JWTs and access after revocation/deletion.
F9 never follows the redirect or contacts attacker.example.

Logs include final successful focused tests, browser cases, OIDC claim test, baseline suite and separate discovery run. The initial failed sandbox and harness-debugging attempts are excluded from the evidence bundle; their causes are documented in the report.
