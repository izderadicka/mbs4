from pathlib import Path
from zipfile import ZipFile, ZIP_STORED
root=Path(__file__).parent
for layout in ['reflowable','pre-paginated']:
    with ZipFile(root / f'{layout}.epub','w') as z:
        z.writestr('mimetype','application/epub+zip',compress_type=ZIP_STORED)
        z.writestr('META-INF/container.xml','''<?xml version="1.0"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="package.opf" media-type="application/oebps-package+xml"/></rootfiles></container>''')
        z.writestr('package.opf',f'''<?xml version="1.0"?><package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="id"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:identifier id="id">security-local-{layout}</dc:identifier><dc:title>Harmless security validation</dc:title><dc:language>en</dc:language><meta property="dcterms:modified">2026-10-18T00:00:00Z</meta><meta property="rendition:layout">{layout}</meta></metadata><manifest><item id="chapter" href="chapter.xhtml" media-type="application/xhtml+xml" properties="scripted"/><item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/></manifest><spine><itemref idref="chapter"/></spine></package>''')
        z.writestr('nav.xhtml','''<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops"><head><title>Contents</title></head><body><nav epub:type="toc"><ol><li><a href="chapter.xhtml">Chapter</a></li></ol></nav></body></html>''')
        z.writestr('chapter.xhtml','''<html xmlns="http://www.w3.org/1999/xhtml"><head><title>Marker</title><meta name="viewport" content="width=600,height=800"/></head><body><p>Harmless local proof</p><script>parent.document.documentElement.dataset.ebookScriptRan='yes'; fetch(new URL('/probe', parent.location.href), {credentials:'include'}).then(r=>r.text()).then(t=>parent.document.documentElement.dataset.authProbe=t);</script></body></html>''')
