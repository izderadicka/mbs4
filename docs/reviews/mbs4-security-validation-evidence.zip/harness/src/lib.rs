#[cfg(test)]
mod tests {
use mbs4_e2e_tests::{prepare_env, launch_env, TestUser, rest::*};
use reqwest::{Client, StatusCode};
use serde_json::{json, Value};
use std::io::Read;

async fn env(name: &str, cors: bool) -> (reqwest::Url, Client, mbs4_app::state::AppState, mbs4_e2e_tests::ConfigGuard) {
    std::fs::create_dir_all("test-data").unwrap();
    let (mut args, mut guard) = prepare_env(name).await.unwrap();
    args.cors = cors;
    args.upload_limit_mb = 1;
    let base = args.base_url.clone();
    let (client, state) = launch_env(args, TestUser::Admin, &mut guard).await.unwrap();
    (base, client, state, guard)
}
fn client_as(state: &mbs4_app::state::AppState, user: TestUser) -> Client {
    Client::builder().default_headers(user.auth_header(state).unwrap()).redirect(reqwest::redirect::Policy::none()).build().unwrap()
}

#[tokio::test]
async fn batch_private_shelf_and_archive_bypass() {
    let (base, admin, state, _guard) = env("batch", false).await;
    create_format(&admin, &base, "EPUB", "application/epub+zip", "epub").await.unwrap();
    let lang = create_language(&admin, &base, "English", "en").await.unwrap();
    let book = create_ebook(&admin, &base, &json!({"title":"Private membership marker", "language_id":lang.id})).await.unwrap();
    let shelf: Value = admin.post(base.join("api/bookshelf").unwrap()).json(&json!({"name":"Private shelf marker", "public":false})).send().await.unwrap().error_for_status().unwrap().json().await.unwrap();
    let id = shelf["id"].as_i64().unwrap();
    admin.post(base.join(&format!("api/bookshelf/{id}/items")).unwrap()).json(&json!({"item_type":"EBOOK", "ebook_id":book.id})).send().await.unwrap().error_for_status().unwrap();
    let trusted = client_as(&state, TestUser::TrustedUser);
    let ordinary = client_as(&state, TestUser::User);
    assert_eq!(trusted.get(base.join(&format!("api/bookshelf/{id}")).unwrap()).send().await.unwrap().status(), StatusCode::FORBIDDEN);
    let ticket: Value = trusted.post(base.join("api/convert/batch").unwrap()).json(&json!({"for_entity":"BOOKSHELF","entity_id":id,"to_format_extension":"epub"})).send().await.unwrap().error_for_status().unwrap().json().await.unwrap();
    assert_eq!(ticket["total"], 1);
    let batch = ticket["batch_id"].as_i64().unwrap();
    let meta_url = base.join(&format!("api/conversion-batch/{batch}")).unwrap();
    let mut metadata = Value::Null;
    for _ in 0..100 {
        metadata = trusted.get(meta_url.clone()).send().await.unwrap().error_for_status().unwrap().json().await.unwrap();
        if metadata["zip_location"].is_string() { break; }
        tokio::time::sleep(std::time::Duration::from_millis(50)).await;
    }
    assert!(metadata["name"].as_str().unwrap().contains("Private shelf marker"));
    assert_eq!(ordinary.get(meta_url).send().await.unwrap().status(), StatusCode::FORBIDDEN);
    let zip_path = metadata["zip_location"].as_str().unwrap();
    let bytes = ordinary.get(base.join(&format!("files/download/conversion/{zip_path}")).unwrap()).send().await.unwrap().error_for_status().unwrap().bytes().await.unwrap();
    let mut archive = zip::ZipArchive::new(std::io::Cursor::new(bytes)).unwrap();
    let mut manifest = String::new();
    archive.by_name("manifest.txt").unwrap().read_to_string(&mut manifest).unwrap();
    assert!(manifest.contains("Private membership marker"));
    assert!(manifest.contains(&format!("id={}", book.id)));
    println!("F4: private shelf GET=403, conversion=200, name and membership disclosed. F5: non-owner metadata=403, ZIP=200. Manifest: {manifest}");
}

#[tokio::test]
async fn oversized_upload_with_length_and_chunked() {
    let (base, admin, state, _guard) = env("upload", false).await;
    create_format(&admin, &base, "Text", "text/plain", "txt").await.unwrap();
    let trusted = client_as(&state, TestUser::TrustedUser);
    for chunked in [false, true] {
        let body = vec![if chunked {b'b'} else {b'a'}; 1024*1024+17];
        let req = trusted.post(base.join("files/upload/direct").unwrap()).header("content-type", "text/plain");
        let req = if chunked { req.body(reqwest::Body::wrap_stream(futures::stream::iter(vec![Ok::<_,std::io::Error>(body)]))) } else { req.body(body) };
        let res = req.send().await.unwrap();
        assert_eq!(res.status(), StatusCode::CREATED);
        let info: Value = res.json().await.unwrap();
        assert_eq!(info["size"], 1024*1024+17);
        println!("F7: chunked={chunked}, limit=1048576, accepted=1048593, status=201");
    }
    let multipart = reqwest::multipart::Form::new().part("file", reqwest::multipart::Part::bytes(vec![b'c';1024*1024+17]).file_name("control.txt"));
    let res = trusted.post(base.join("files/upload/form").unwrap()).multipart(multipart).send().await.unwrap();
    assert!(!res.status().is_success());
    println!("F7 control: oversized multipart rejected with {}", res.status());
}

#[tokio::test]
async fn forwarding_header_rate_limit_bypass() {
    let (base, _, _, _guard) = env("rate", false).await;
    let client = Client::new();
    for n in 0..11 {
        let res = client.post(base.join("auth/login?token=true").unwrap()).json(&json!({"email":"absent@example.test","password":"invalid-password"})).send().await.unwrap();
        assert_eq!(res.status(), if n<10 {StatusCode::UNAUTHORIZED} else {StatusCode::TOO_MANY_REQUESTS});
    }
    for header in ["x-forwarded-for", "forwarded"] {
        for n in 1..=11 {
            let value = if header == "forwarded" {format!("for=198.51.100.{n}")} else {format!("192.0.2.{n}")};
            let res = client.post(base.join("auth/login?token=true").unwrap()).header(header, value).json(&json!({"email":"absent@example.test","password":"invalid-password"})).send().await.unwrap();
            assert_eq!(res.status(), StatusCode::UNAUTHORIZED);
        }
    }
    println!("F6: same peer throttled on attempt 11; 11 rotating XFF and 11 rotating Forwarded values each bypassed 429");
}

#[tokio::test]
async fn cors_arbitrary_origin() {
    for enabled in [false,true] {
        let (base, admin, _, _guard) = env("cors", enabled).await;
        let origin = "https://untrusted.example";
        let res = admin.get(base.join("users").unwrap()).header("origin", origin).send().await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        if enabled {
            assert_eq!(res.headers()["access-control-allow-origin"], origin);
            assert_eq!(res.headers()["access-control-allow-credentials"], "true");
        } else { assert!(res.headers().get("access-control-allow-origin").is_none()); }
        let pre = admin.request(reqwest::Method::OPTIONS, base.join("users").unwrap()).header("origin",origin).header("access-control-request-method","POST").header("access-control-request-headers","content-type").send().await.unwrap();
        if enabled {
            assert_eq!(pre.headers()["access-control-allow-origin"], origin);
            assert_eq!(pre.headers()["access-control-allow-credentials"], "true");
            assert_eq!(pre.headers()["access-control-allow-methods"], "POST");
        } else { assert!(pre.headers().get("access-control-allow-origin").is_none()); }
        println!("F3: cors={enabled}, arbitrary-origin credentialed GET and POST-preflight approval={enabled}");
    }
}

#[tokio::test]
async fn stale_session_and_open_redirect() {
    use mbs4_dal::user::{UserRepository, CreateUser};
    let (base, _, state, _guard) = env("session", false).await;
    let repo = UserRepository::new(state.pool().clone());
    let user = repo.create(CreateUser { email:"victim@example.test".parse().unwrap(), name:"Test victim".into(), password:Some("local-test-password".into()), roles:Some(vec!["admin".into()]) }).await.unwrap();
    let client = Client::builder().redirect(reqwest::redirect::Policy::none()).build().unwrap();
    let mut saved_cookie = String::new();
    let mut saved_trt = String::new();
    for redirect in ["/", "//attacker.example/collect", "/\\attacker.example/collect"] {
        let res = client.post(base.join("auth/login").unwrap()).query(&[("redirect",redirect)]).json(&json!({"email":user.email,"password":"local-test-password"})).send().await.unwrap();
        assert_eq!(res.status(), StatusCode::SEE_OTHER);
        let location = reqwest::Url::parse(res.headers()["location"].to_str().unwrap()).unwrap();
        assert_eq!(location.host_str().unwrap(), if redirect=="/" {"localhost"} else {"attacker.example"});
        let trt = location.query_pairs().find(|(k,_)|k=="trt").unwrap().1.into_owned();
        if redirect=="/" {
            saved_trt=trt;
            saved_cookie=res.headers().get_all("set-cookie").iter().map(|h|h.to_str().unwrap().split(';').next().unwrap()).find(|h|h.starts_with("mbs4=")).unwrap().to_string();
        }
        println!("F9: redirect={redirect:?}, resulting host={}", location.host_str().unwrap());
    }
    sqlx_remove_roles(&state, user.id).await;
    for stage in ["role removed", "account deleted"] {
        if stage=="account deleted" { repo.delete(user.id).await.unwrap(); }
        let res = client.get(base.join("auth/token").unwrap()).query(&[("trt", &saved_trt)]).header("cookie",&saved_cookie).send().await.unwrap();
        assert_eq!(res.status(),StatusCode::OK);
        let token=res.text().await.unwrap();
        let claims: mbs4_types::claim::ApiClaim = state.tokens().validate(&token).unwrap();
        assert!(claims.roles.contains(&mbs4_types::claim::Role::Admin));
        let proof=client.get(base.join("users").unwrap()).bearer_auth(token).send().await.unwrap();
        assert_eq!(proof.status(),StatusCode::OK);
        println!("F8: {stage}: token exchange=200, newly issued JWT retains admin, admin API=200");
    }
}
async fn sqlx_remove_roles(state: &mbs4_app::state::AppState, id:i64) {
    mbs4_dal::user::UserRepository::new(state.pool().clone()).update(id,mbs4_dal::user::UpdateUser {name:"Test victim".into(),password:None,roles:Some(vec![])}).await.unwrap();
}
}

#[test]
fn oidc_unverified_email_claim_accepted() {
    use openidconnect::core::{CoreIdToken, CoreIdTokenClaims, CoreHmacKey, CoreJwsSigningAlgorithm};
    use mbs4_auth::oidc::IDToken;
    use mbs4_types::claim::UserClaim;
    let now=std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_secs();
    for verified in [Some(false), None, Some(true)] {
        let mut value=serde_json::json!({"iss":"https://provider.example","aud":"test-client","exp":now+300,"iat":now,"sub":"different-attacker-subject","email":"admin@example.test"});
        if let Some(v)=verified { value["email_verified"]=serde_json::json!(v); }
        let claims:CoreIdTokenClaims=serde_json::from_value(value).unwrap();
        let id_token=CoreIdToken::new(claims.clone(),&CoreHmacKey::new("local-test-signing-key"),CoreJwsSigningAlgorithm::HmacSha256,None,None).unwrap();
        let value=IDToken{claims,id_token,access_token:None,refresh_token:None};
        let user=UserClaim::try_from(&value).unwrap();
        assert_eq!(user.email,"admin@example.test");
        assert_eq!(user.sub,"different-attacker-subject");
        println!("F2: email_verified={verified:?}, UserClaim accepts existing-account email with a different subject (claim-conversion unit test, not provider callback)");
    }
}
