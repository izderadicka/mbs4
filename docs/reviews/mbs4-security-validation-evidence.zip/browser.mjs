import { chromium } from '/workspace/mbs4-client/node_modules/playwright/index.mjs';
import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
const root=path.dirname(new URL(import.meta.url).pathname);
const foliate='/workspace/mbs4-client/node_modules/foliate-js';
const defaultCSP="object-src 'none'; base-uri 'self'; frame-ancestors 'none'";
const server=http.createServer(async(req,res)=>{
  const url=new URL(req.url,'http://localhost');
  res.setHeader('Cross-Origin-Opener-Policy','same-origin');
  res.setHeader('Cross-Origin-Embedder-Policy','require-corp');
  res.setHeader('Cross-Origin-Resource-Policy','same-origin');
  if(url.pathname==='/'){
    res.setHeader('Content-Type','text/html');
    res.setHeader('Content-Security-Policy',defaultCSP+(url.searchParams.has('strict')?"; script-src 'self'":""));
    res.setHeader('Set-Cookie','review_session=local-marker; HttpOnly; SameSite=Strict; Path=/');
    res.end('<!doctype html><html><head><title>Local reader security test</title></head><body><script type="module" src="/harness.js"></script></body></html>');
  } else if(url.pathname==='/harness.js'){
    res.setHeader('Content-Type','text/javascript');
    res.end(`import '/foliate/view.js'; const layout=new URL(location.href).searchParams.get('layout'); const v=document.createElement('foliate-view'); v.style.cssText='display:block;width:800px;height:900px'; document.body.append(v); const bytes=await (await fetch('/'+layout+'.epub')).blob(); await v.open(new File([bytes],layout+'.epub',{type:'application/epub+zip'})); await v.init({}); document.documentElement.dataset.ready='yes';`);
  } else if(url.pathname==='/probe'){
    res.setHeader('Content-Type','text/plain');
    res.end((req.headers.cookie||'').includes('review_session=local-marker')?'authenticated-marker':'unauthenticated');
  } else {
    try {
      const file=url.pathname.startsWith('/foliate/')?path.join(foliate,url.pathname.slice(9)):path.join(root,path.basename(url.pathname));
      res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':file.endsWith('.epub')?'application/epub+zip':'application/octet-stream');
      res.end(await fs.readFile(file));
    }catch{res.statusCode=404;res.end();}
  }
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
console.log('Browser:',browser.version());
try{
  for(const layout of ['reflowable','pre-paginated'])for(const strict of [false,true]){
    const page=await browser.newPage(); const errors=[];
    page.on('pageerror',e=>errors.push(e.message));
    await page.goto(`http://127.0.0.1:${server.address().port}/?layout=${layout}${strict?'&strict=1':''}`);
    await page.waitForFunction(()=>document.documentElement.dataset.ready==='yes');
    if(!strict)await page.waitForFunction(()=>document.documentElement.dataset.authProbe==='authenticated-marker');
    else await page.waitForTimeout(500);
    const result=await page.evaluate(()=>({marker:document.documentElement.dataset.ebookScriptRan??null,authProbe:document.documentElement.dataset.authProbe??null,isolated:crossOriginIsolated}));
    assert.equal(result.marker,strict?null:'yes');
    assert.equal(result.authProbe,strict?null:'authenticated-marker');
    console.log(JSON.stringify({layout,strict,...result,errors}));
    await page.close();
  }
}finally{await browser.close();server.close();}
